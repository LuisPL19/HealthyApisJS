function getRecipes() {
    // Verifica se as receitas já estão em cache
    const cachedRecipes = localStorage.getItem('cachedRecipes');
    if (cachedRecipes) {
        // Se as receitas estiverem em cache, exibe as receitas armazenadas
        displayRecipes(JSON.parse(cachedRecipes));
    } else {
        // Se as receitas não estiverem em cache, busca as receitas da API
        const apiKey = '154954bef317437e8da755ffad09bb6f';
        fetch(`https://api.spoonacular.com/recipes/random?apiKey=${apiKey}&number=12`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erro ao carregar as receitas');
                }
                return response.json();
            })
            .then(data => {
                const recipes = data.recipes;

                // Armazena as receitas em cache
                localStorage.setItem('cachedRecipes', JSON.stringify(recipes));

                // Exibe as receitas
                displayRecipes(recipes);
            })
            .catch(error => console.error('Ocorreu um erro ao fazer a solicitação:', error.message));
    }
}

function displayRecipes(recipes) {
    const recipeList = document.getElementById('recipe-list');

    // Limpa a lista de receitas antes de adicionar as novas
    recipeList.innerHTML = '';

    recipes.forEach(recipe => {
        // Cria uma div para cada receita e adiciona ao recipeList
        const recipeItem = document.createElement('div');
        recipeItem.classList.add('col-md-3', 'mb-4');

        // Cria uma card para exibir a receita
        const card = document.createElement('div');
        card.classList.add('card');
        recipeItem.appendChild(card);

        // Adiciona a imagem da receita
        const recipeImage = document.createElement('img');
        recipeImage.classList.add('card-img-top');
        recipeImage.src = recipe.image;
        recipeImage.alt = recipe.title;
        card.appendChild(recipeImage);

        // Adiciona o corpo do card
        const cardBody = document.createElement('div');
        cardBody.classList.add('card-body');
        card.appendChild(cardBody);

        // Adiciona o título da receita
        const recipeTitle = document.createElement('h5');
        recipeTitle.classList.add('card-title');
        recipeTitle.textContent = recipe.title;
        cardBody.appendChild(recipeTitle);

        // Adiciona um botão para abrir o modal com a receita completa
        const recipeButton = document.createElement('button');
        recipeButton.classList.add('btn', 'btn-primary');
        recipeButton.textContent = 'Ver Receita';
        recipeButton.dataset.toggle = 'modal';
        recipeButton.dataset.target = '#recipeModal';
        recipeButton.addEventListener('click', () => {
            // Atualiza o conteúdo do modal com os dados da receita
            document.getElementById('recipeModalLabel').textContent = recipe.title;
            document.getElementById('recipeImage').src = recipe.image;
            const ingredientsList = document.getElementById('recipeIngredients');
            ingredientsList.innerHTML = '';
            if (recipe.extendedIngredients && recipe.extendedIngredients.length > 0) {
                recipe.extendedIngredients.forEach(ingredient => {
                    const ingredientItem = document.createElement('li');
                    ingredientItem.textContent = ingredient.original;
                    ingredientsList.appendChild(ingredientItem);
                });
            } else {
                const ingredientItem = document.createElement('li');
                ingredientItem.textContent = 'Ingredientes não disponíveis';
                ingredientsList.appendChild(ingredientItem);
            }

            const instructionsContainer = document.getElementById('recipeInstructions');
            instructionsContainer.innerHTML = ''; // Limpa o conteúdo anterior das instruções

            // Verifica se as instruções são fornecidas em HTML e as exibe adequadamente
            if (recipe.instructions) {
                const instructionsFragment = document.createRange().createContextualFragment(recipe.instructions);
                instructionsContainer.appendChild(instructionsFragment);
            } else {
                instructionsContainer.textContent = 'Instruções não disponíveis';
            }
        });
        cardBody.appendChild(recipeButton);

        // Adiciona o card à lista de receitas
        recipeList.appendChild(recipeItem);
    });
}

// Chama a função getRecipes() quando a página é carregada
document.addEventListener('DOMContentLoaded', getRecipes);


